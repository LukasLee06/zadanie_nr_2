﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Moja_strona.Data;
using Moja_strona.Models;

namespace Moja_strona.Controllers
{
    public class KsiazkisController : Controller
    {
        private readonly KsiazkiContext _context;

        public KsiazkisController(KsiazkiContext context)
        {
            _context = context;
        }

        // GET: Ksiazkis
        public async Task<IActionResult> Index()
        {
            return View(await _context.Ksiazki.ToListAsync());
        }

        // GET: Ksiazkis/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ksiazki = await _context.Ksiazki
                .FirstOrDefaultAsync(m => m.Id == id);
            if (ksiazki == null)
            {
                return NotFound();
            }

            return View(ksiazki);
        }

        // GET: Ksiazkis/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Ksiazkis/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Tytul,Data,Genre,Price")] Ksiazki ksiazki)
        {
            if (ModelState.IsValid)
            {
                _context.Add(ksiazki);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(ksiazki);
        }

        // GET: Ksiazkis/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ksiazki = await _context.Ksiazki.FindAsync(id);
            if (ksiazki == null)
            {
                return NotFound();
            }
            return View(ksiazki);
        }

        // POST: Ksiazkis/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Tytul,Data,Genre,Price")] Ksiazki ksiazki)
        {
            if (id != ksiazki.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(ksiazki);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!KsiazkiExists(ksiazki.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(ksiazki);
        }

        // GET: Ksiazkis/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ksiazki = await _context.Ksiazki
                .FirstOrDefaultAsync(m => m.Id == id);
            if (ksiazki == null)
            {
                return NotFound();
            }

            return View(ksiazki);
        }

        // POST: Ksiazkis/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ksiazki = await _context.Ksiazki.FindAsync(id);
            _context.Ksiazki.Remove(ksiazki);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool KsiazkiExists(int id)
        {
            return _context.Ksiazki.Any(e => e.Id == id);
        }
    }
}
