﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Moja_strona.Data;
using Moja_strona.Models;

namespace Moja_strona.Controllers
{
    public class OdcinkisController : Controller
    {
        private readonly OdcinkiContext _context;

        public OdcinkisController(OdcinkiContext context)
        {
            _context = context;
        }

        // GET: Odcinkis
        public async Task<IActionResult> Index()
        {
            return View(await _context.Odcinki.ToListAsync());
        }

        // GET: Odcinkis/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var odcinki = await _context.Odcinki
                .FirstOrDefaultAsync(m => m.Id == id);
            if (odcinki == null)
            {
                return NotFound();
            }

            return View(odcinki);
        }

        // GET: Odcinkis/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Odcinkis/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Tytul,Data")] Odcinki odcinki)
        {
            if (ModelState.IsValid)
            {
                _context.Add(odcinki);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(odcinki);
        }

        // GET: Odcinkis/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var odcinki = await _context.Odcinki.FindAsync(id);
            if (odcinki == null)
            {
                return NotFound();
            }
            return View(odcinki);
        }

        // POST: Odcinkis/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Tytul,Data")] Odcinki odcinki)
        {
            if (id != odcinki.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(odcinki);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OdcinkiExists(odcinki.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(odcinki);
        }

        // GET: Odcinkis/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var odcinki = await _context.Odcinki
                .FirstOrDefaultAsync(m => m.Id == id);
            if (odcinki == null)
            {
                return NotFound();
            }

            return View(odcinki);
        }

        // POST: Odcinkis/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var odcinki = await _context.Odcinki.FindAsync(id);
            _context.Odcinki.Remove(odcinki);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OdcinkiExists(int id)
        {
            return _context.Odcinki.Any(e => e.Id == id);
        }
    }
}
