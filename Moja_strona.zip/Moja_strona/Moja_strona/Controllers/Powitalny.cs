﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Moja_strona.Controllers
{
    public class Powitalny : Controller
    {

        //
        // GET: /Powitalny/
        public IActionResult Index()
        {
            return View();
        }

        //
        // GET: /Powitalny/Postac
        public IActionResult Postac()
        {
            return View();
        }

        //
        // GET: /Powitalny/Welcome/
        public string Welcome()
        {
            return "This is the Welcome action method...";
        }
    }
}
