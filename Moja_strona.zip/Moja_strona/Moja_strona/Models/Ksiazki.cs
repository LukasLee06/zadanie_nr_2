﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Moja_strona.Models;

namespace Moja_strona.Models
{
    public class Ksiazki
    {

        public int Id { get; set; }
        public string Tytul { get; set; }
        [DataType(DataType.Date)]
        public DateTime Data { get; set; }
        public string Genre { get; set; }
        public decimal Price { get; set; }

    }
}
