﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace Moja_strona.Models
{
    public class Odcinki
    {

        public int Id { get; set; }
        public string Tytul { get; set; }
        [DataType(DataType.Date)]
        public DateTime Data { get; set; }
        
    }
}
