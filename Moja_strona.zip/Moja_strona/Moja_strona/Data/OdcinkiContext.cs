﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Moja_strona.Models;

namespace Moja_strona.Data
{
    public class OdcinkiContext : DbContext
    {

        public OdcinkiContext(DbContextOptions<OdcinkiContext> options)
        : base(options)
        {
        }
        public DbSet<Odcinki> Odcinki { get; set; }

    }
}
