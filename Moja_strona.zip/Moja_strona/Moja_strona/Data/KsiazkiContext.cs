﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Moja_strona.Models;


namespace Moja_strona.Data
{
    public class KsiazkiContext : DbContext
    {
        public KsiazkiContext(DbContextOptions<KsiazkiContext> options)
            : base(options)
        {
        }
        public DbSet<Ksiazki> Ksiazki { get; set; }
    }
}
